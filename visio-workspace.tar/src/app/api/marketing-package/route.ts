import { NextResponse } from "next/server";

export async function POST(request: Request) {
  await new Promise((resolve) => setTimeout(resolve, 1000));

  const body = await request.json().catch(() => null);

  return NextResponse.json({
    success: true,
    status: "completed",
    message: "Marketing paket yaratildi",
    data: {
      id: `pkg-${Date.now()}`,
      renderId: body?.renderId || "render-001",
      createdAt: new Date().toISOString(),
      assets: [
        {
          type: "instagram_post",
          format: "JPG",
          resolution: "1080x1350",
          url: "/placeholder-ig.jpg",
          size: "2.4 MB",
        },
        {
          type: "facebook_banner",
          format: "PNG",
          resolution: "1200x628",
          url: "/placeholder-fb.png",
          size: "1.8 MB",
        },
        {
          type: "pdf_brochure",
          format: "PDF",
          pages: 4,
          url: "/placeholder-brochure.pdf",
          size: "5.2 MB",
        },
        {
          type: "video_reel",
          format: "MP4",
          duration: "15s",
          resolution: "1080x1920",
          url: "/placeholder-reel.mp4",
          size: "8.1 MB",
        },
      ],
    },
    meta: {
      generationTime: "45s",
      templateVersion: "2026.1",
    },
  });
}
