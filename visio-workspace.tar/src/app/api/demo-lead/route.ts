import { NextResponse } from "next/server";

export async function POST(request: Request) {
  await new Promise((resolve) => setTimeout(resolve, 800));

  const body = await request.json().catch(() => null);

  const { name, phone, company, message } = body || {};

  // Validation
  if (!name || !phone) {
    return NextResponse.json(
      { success: false, error: "Ism va telefon raqam talab qilinadi" },
      { status: 400 }
    );
  }

  return NextResponse.json({
    success: true,
    message: "So'rov qabul qilindi",
    data: {
      id: `lead-${Date.now()}`,
      name,
      phone,
      company: company || null,
      message: message || null,
      status: "new",
      createdAt: new Date().toISOString(),
      assignedTo: "VISIO Sales Team",
      expectedFollowUp: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
    },
  });
}
